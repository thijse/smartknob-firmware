#include "app.h"
#include <logging.h>

App::App(SemaphoreHandle_t mutex) : mutex_(mutex)
{
    LOGI("App: Constructor called, creating new screen");
    
    // Always create a fresh screen for each App/Component instance
    screen = lv_obj_create(NULL);
    
    if (screen != nullptr && (uintptr_t)screen != 0xa5a5a5a5 && (uintptr_t)screen > 0x1000)
    {
        // Try to safely use the screen - wrap in try-catch
        try {
            lv_obj_set_style_bg_color(screen, LV_COLOR_MAKE(0x00, 0x00, 0x00), 0);
            lv_obj_set_size(screen, LV_HOR_RES, LV_VER_RES);
            lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);
            LOGI("App: Screen created and initialized successfully (%p)", screen);
        } catch (...) {
            LOGE("App: Exception during screen initialization");
            screen = nullptr;
        }
    }
    else
    {
        LOGE("App: Failed to create screen or got invalid pointer (%p)", screen);
        screen = nullptr;
    }
}

App::App(SemaphoreHandle_t mutex, int8_t next, int8_t back) : mutex_(mutex), next_(next), back_(back)
{
    LOGI("App: Constructor (with nav) called, creating new screen");
    
    // Always create a fresh screen for each App/Component instance
    screen = lv_obj_create(NULL);
    
    if (screen != nullptr && (uintptr_t)screen != 0xa5a5a5a5 && (uintptr_t)screen > 0x1000)
    {
        try {
            lv_obj_set_style_bg_color(screen, LV_COLOR_MAKE(0x00, 0x00, 0x00), 0);
            lv_obj_set_size(screen, LV_HOR_RES, LV_VER_RES);
            lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);
            LOGI("App: Screen created and initialized successfully (%p)", screen);
        } catch (...) {
            LOGE("App: Exception during screen initialization");
            screen = nullptr;
        }
    }
    else
    {
        LOGE("App: Failed to create screen or got invalid pointer (%p)", screen);
        screen = nullptr;
    }
}

void App::render()
{
    SemaphoreGuard lock(mutex_);
    lv_scr_load(screen);
}

void App::setMotorNotifier(MotorNotifier *motor_notifier)
{
    this->motor_notifier = motor_notifier;
}

void App::triggerMotorConfigUpdate()
{
    if (this->motor_notifier != nullptr)
    {
        motor_notifier->requestUpdate(root_level_motor_config);
    }
    else
    {
        LOGW("Motor_notifier is not set");
    }
}

void App::setNext(int8_t next)
{
    next_ = next;
}
void App::setBack(int8_t back)
{
    back_ = back;
}

PB_SmartKnobConfig App::getMotorConfig()
{
    return motor_config;
}

std::string App::getClassName()
{
    return "App";
}